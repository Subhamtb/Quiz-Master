from flask import Flask,render_template

from backend.models import db

app=None

def setup_app():
    global app
    app=Flask(__name__)
    app.debug=True
    app.config["SQLALCHEMY_DATABASE_URI"]="sqlite:///quiz_master.sqlite3" 
    db.init_app(app)# flask is connected to database.
    app.app_context().push() #Direct access to other modules.
    print("Quiz Master app is started.....")

#call the setup
setup_app()

from backend.controllers import *

if __name__=="__main__":
    app.run()

from flask_sqlalchemy import SQLAlchemy

db=SQLAlchemy()

#User Table
class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(), unique=True, nullable=False)
    password = db.Column(db.String(), nullable=False)
    full_name = db.Column(db.String(), nullable=False)
    qualification = db.Column(db.String())
    dob = db.Column(db.Date)
    role = db.Column(db.String(), nullable=False, default="user")  

    scores = db.relationship('Score',cascade="all,delete", backref='user', lazy=True)

#Subjects Table
class Subject(db.Model):
    __tablename__ = 'subject'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(), nullable=False)
    description = db.Column(db.String())

    chapters = db.relationship('Chapter',cascade="all,delete", backref='subject', lazy=True)

#Chapters Table
class Chapter(db.Model):
    __tablename__ = 'chapter'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(), nullable=False)
    description = db.Column(db.String())
    subject_name = db.Column(db.String(), db.ForeignKey('subject.name'), nullable=False)

    quizzes = db.relationship('Quiz',cascade="all,delete", backref='chapter', lazy=True)

#Quiz Table
class Quiz(db.Model):
    __tablename__ = 'quiz'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(), nullable=False)
    subject_name= db.Column(db.String(), db.ForeignKey('subject.name'), nullable=False)
    chapter_name = db.Column(db.String(), db.ForeignKey('chapter.name'), nullable=False)
    date_of_quiz = db.Column(db.Date, nullable=False)
    time_duration = db.Column(db.String(), nullable=False)  #in munites
    remarks = db.Column(db.String())

    questions = db.relationship('Question',cascade="all,delete",backref='quiz', lazy=True)
    scores = db.relationship('Score',cascade="all,delete", backref='quiz', lazy=True)


#Questions Table
class Question(db.Model):
    __tablename__ = 'question'
    id = db.Column(db.Integer, primary_key=True)
    title=db.Column(db.String(), nullable=False)
    chapter_name=db.Column(db.String(), nullable=False)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    question_statement = db.Column(db.Text, nullable=False)
    option1 = db.Column(db.String(), nullable=False)
    option2 = db.Column(db.String(), nullable=False)
    option3 = db.Column(db.String(), nullable=False)
    option4 = db.Column(db.String(), nullable=False)
    correct_option = db.Column(db.String(), nullable=False)  


#Score Table
class Score(db.Model):
    __tablename__ = 'score'
    id = db.Column(db.Integer, primary_key=True)
    quiz_name = db.Column(db.String(), db.ForeignKey('quiz.name'), nullable=False)
    user_name = db.Column(db.String(), db.ForeignKey('user.email'), nullable=False)
    time_stamp_of_attempt = db.Column(db.DateTime, nullable=False)
    total_score = db.Column(db.String(), nullable=False)
    marks_obtained = db.Column(db.String(), nullable=False)


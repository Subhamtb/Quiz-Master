from flask import Flask,render_template,request,redirect,url_for,flash
from flask import current_app as app
from datetime import datetime
from backend.models import *
import matplotlib
matplotlib.use('Agg')  # Switch to non-GUI backend


import matplotlib.pyplot as plt

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/login",methods=["GET","POST"])
def signin():
    if request.method=="POST":
        uname=request.form.get("user_name")
        pwd=request.form.get("password")
        usr=User.query.filter_by(email=uname,password=pwd).first()
        if usr and usr.role=="admin":
            return redirect(url_for("admin_dashboard",name=uname))
        
        elif usr and usr.role=="user":
            return redirect(url_for("user_dashboard",name=uname))
        else:
            return render_template("login.html",msg="Invalid User Credentials....")
                
    return render_template("login.html",msg="")

@app.route("/register",methods=["GET","POST"])
def signup():
    if request.method=="POST":
        uname=request.form.get("user_name")
        pwd=request.form.get("password")
        full_name=request.form.get("full_name")
        qf=request.form.get("qualification")
        dob=request.form.get("dob")
        dob_date = datetime.strptime(dob, "%Y-%m-%d").date()
        usr=User.query.filter_by(email=uname).first()
        if usr:
            return render_template("signup.html",msg="Sorry this Email already registered!!!")
        new_usr=User(email=uname,password=pwd,full_name=full_name,qualification=qf,dob=dob_date)
        db.session.add(new_usr)
        db.session.commit()
        return render_template("login.html",msg="Registration Successfull..")


    return render_template("signup.html",msg="")


@app.route("/admin/<name>")
def admin_dashboard(name):
    subject=get_subject()
    return render_template('admin_dashboard.html',name=name,Subject=subject)

@app.route("/user/<name>")
def user_dashboard(name):
    qz=get_quiz()
    return render_template('user_dashboard.html',name=name,Quiz=qz)


@app.route("/add_subject/<name>",methods=["GET","POST"])
def add_subject(name):
    if request.method=="POST":
        nm=request.form.get("name")
        desc=request.form.get("description")
        new_sub=Subject(name=nm,description=desc)
        db.session.add(new_sub)
        db.session.commit()
        return redirect(url_for("admin_dashboard",name=name))
    
    return render_template("add_subject.html",name=name)

def get_subject():
    subject=Subject.query.all()
    return subject

def get_subj_id(name):
    id=Subject.query.filter_by(name=name).first()

@app.route("/add_chapter/<sub_name>/<name>",methods=["GET","POST"])
def add_chapter(sub_name,name):
    if request.method=="POST":
        nm=request.form.get("name")
        desc=request.form.get("description")
        new_chap=Chapter(name=nm,description=desc,subject_name=sub_name)
        db.session.add(new_chap)
        db.session.commit()
        return redirect(url_for("admin_dashboard",name=name))
    
    return render_template("add_chapter.html",subject_name=sub_name,name=name)

@app.route("/search/<name>",methods=["GET","POST"])
def search(name):
    if request.method=='POST':
        serach_txt=request.form.get("search")
        if serach_txt=="":
            return redirect(url_for("admin_dashboard",name=name))
        by_user=search_by_user(serach_txt)
        by_subject=search_by_subject(serach_txt)
        by_name=search_by_name(serach_txt)
        
        if by_user:
            return render_template("admin_search.html",name=name,User=by_user)
        elif by_subject:
            return render_template("admin_search.html",name=name,Subject=by_subject)
        elif by_name:
            return render_template("admin_search.html",name=name,Quiz=by_name)
    


    return redirect(url_for('admin_dashboard',name=name))

def search_by_user(search_txt):
    users=User.query.filter(User.full_name.ilike(f"%{search_txt}%")).all()
    return users

def search_by_subject(search_txt):
    subjects=Subject.query.filter(Subject.name.ilike(f"%{search_txt}%")).all()
    return subjects

def search_by_name(search_txt):
    quizes=Quiz.query.filter(Quiz.name.ilike(f"%{search_txt}%")).all()
    return quizes

def search_subj_by_name(sname):
    sub=Subject.query.filter_by(name=sname).first()
    return sub

@app.route("/edit_subject/<sname>/<name>",methods=["GET","POST"])
def edit_subject(sname,name):
    sub=search_subj_by_name(sname)
    if request.method=="POST":
        nm=request.form.get("name")
        desc=request.form.get("description")
        sub.name=nm
        sub.description=desc
        db.session.commit()
        return redirect(url_for("admin_dashboard",name=name))
    
    return render_template('edit_subject.html',Subject=sub,name=name)

@app.route("/delete_subject/<sname>/<name>",methods=['POST','GET'])
def delete_subject(sname,name):
    sub=search_subj_by_name(sname)
    db.session.delete(sub)
    db.session.commit()
    return redirect(url_for("admin_dashboard",name=name))


@app.route("/edit_chapter/<cname>/<name>",methods=["GET","POST"])
def edit_chapter(cname,name):
    chp=search_chap_by_name(cname)
    if request.method=="POST":
        nm=request.form.get("name")
        desc=request.form.get("description")
        chp.name=nm
        chp.description=desc
        db.session.commit()
        return redirect(url_for("admin_dashboard",name=name))
    
    return render_template('edit_chapter.html',Chapter=chp,name=name)


def search_chap_by_name(cname):
    chp=Chapter.query.filter_by(name=cname).first()
    return chp


@app.route("/delete_chapter/<cname>/<name>",methods=['POST','GET'])
def delete_chapter(cname,name):
    chp=search_chap_by_name(cname)
    db.session.delete(chp)
    db.session.commit()
    return redirect(url_for("admin_dashboard",name=name))

@app.route("/admin_quiz/<name>")
def admin_quiz(name):
    qz=get_quiz()
    return render_template('admin_quiz.html',name=name,Quiz=qz)

 
def get_quiz():
    qz=Quiz.query.all()
    return qz

def get_chapter():
    cp=Chapter.query.all()
    return cp

@app.route("/add_quiz/<name>",methods=["GET","POST"])
def add_quiz(name):
    sub=get_subject()
    chp=get_chapter()
    if request.method=="POST":
        nm=request.form.get("name")
        sub_nm=request.form.get("subject")
        chp_nm=request.form.get("chapter")
        date=request.form.get("date_of_quiz")
        time=request.form.get("time_duration")
        quiz_date = datetime.strptime(date, "%Y-%m-%d").date()

        cp=search_chap_by_name(chp_nm)

        if cp.subject_name==sub_nm:
             new_quiz=Quiz(name=nm,subject_name=sub_nm,chapter_name=chp_nm,date_of_quiz=quiz_date,time_duration=time)
             db.session.add(new_quiz)
             db.session.commit()
             return redirect(url_for("admin_quiz",name=name))
        else:
            return render_template("add_quiz.html",name=name,Subject=sub,Chapter=chp,msg="The Chapter's subject name and the subject name you entered are different!!!")

    return render_template("add_quiz.html",name=name,Subject=sub,Chapter=chp,mas="")


def get_quiz_by_name(qname):
    qz=Quiz.query.filter_by(name=qname).first()
    return qz

@app.route("/edit_quiz/<qname>/<name>",methods=["GET","POST"])
def edit_quiz(qname,name):
    qz=get_quiz_by_name(qname)
    if request.method=="POST":
        nm=request.form.get("name")
        sub_nm=request.form.get("subject_name")
        chp_nm=request.form.get("chapter_name")
        dt=request.form.get("date_of_quiz")
        time=request.form.get("time_duration")
        date_of_quiz=datetime.strptime(dt, "%Y-%m-%d").date()
        qz.name=nm
        qz.subject_name=sub_nm
        qz.chp_name=chp_nm
        qz.date_of_quiz=date_of_quiz
        qz.time_duration=time
        db.session.commit()
        return redirect(url_for("admin_quiz",name=name))
    
    return render_template('edit_quiz.html',Quiz=qz,name=name)

@app.route("/delete_quiz/<qname>/<name>",methods=['POST','GET'])
def delete_quiz(qname,name):
    qz=get_quiz_by_name(qname)
    db.session.delete(qz)
    db.session.commit()
    return redirect(url_for("admin_quiz",name=name))


@app.route("/add_question/<quiz_name>/<name>",methods=["GET","POST"])
def add_question(quiz_name,name):
    qz=get_quiz_by_name(quiz_name)
    if request.method=="POST":
        chp_nm=request.form.get("chapter_name")
        title=request.form.get("title")
        quiz_id=request.form.get("quiz_id")
        question_statement=request.form.get("question_statement")
        option1=request.form.get("option1")
        option2=request.form.get("option2")
        option3=request.form.get("option3")
        option4=request.form.get("option4")
        correct_option=request.form.get("correct_option")

        new_qst=Question(chapter_name=chp_nm,title=title,quiz_id=quiz_id,question_statement=question_statement,option1=option1,option2=option2,option3=option3,option4=option4,correct_option=correct_option)
        db.session.add(new_qst)
        db.session.commit()
        return redirect(url_for("admin_quiz",name=name))
    
    return render_template("add_question.html",Quiz=qz,name=name)

def search_question_by_name(question_title):
    qs=Question.query.filter_by(title=question_title).first()
    return qs

@app.route("/edit_question/<question_title>/<name>",methods=["GET","POST"])
def edit_question(question_title,name):
    qus=search_question_by_name(question_title)
    if request.method=="POST":
        title=request.form.get("title")
        question_statement=request.form.get("question_statement")
        option1=request.form.get("option1")
        option2=request.form.get("option2")
        option3=request.form.get("option3")
        option4=request.form.get("option4")
        correct_option=request.form.get("correct_option")

        qus.title=title
        qus.question_statement=question_statement
        qus.option1=option1
        qus.option2=option2
        qus.option3=option3
        qus.option4=option4
        qus.correct_option=correct_option
        db.session.commit()
        return redirect(url_for("admin_quiz",name=name))
    
    return render_template('edit_question.html',Question=qus,name=name)

@app.route("/delete_question/<question_title>/<name>",methods=['POST','GET'])
def delete_question(question_title,name):
    qs=search_question_by_name(question_title)
    db.session.delete(qs)
    db.session.commit()
    return redirect(url_for("admin_quiz",name=name))

def get_user_by_name(uname):
    usr=User.query.filter_by(full_name=uname).first()
    return usr


@app.route("/edit_user/<uname>/<name>",methods=["GET","POST"])
def edit_user(uname,name):
    usr=get_user_by_name(uname)
    if request.method=="POST":
        nm=request.form.get("full_name")
        qf=request.form.get("qualification")
        dob=request.form.get("dob")
        dob_date = datetime.strptime(dob, "%Y-%m-%d").date()
        usr.full_name=nm
        usr.qualification=qf
        usr.dob=dob_date
        db.session.commit()
        return redirect(url_for("admin_quiz",name=name))
    
    return render_template('edit_user.html',User=usr,name=name)


@app.route("/delete_user/<uname>/<name>",methods=['POST','GET'])
def delete_user(uname,name):
    usr=get_user_by_name(uname)
    db.session.delete(usr)
    db.session.commit()
    return redirect(url_for("admin_quiz",name=name))

@app.route("/view_quiz/<qname>/<name>")
def view_quiz(qname,name):
    qz=get_quiz_by_name(qname)
    return render_template('view_quiz.html',Quiz=qz,name=name)

def get_quiz_by_subject(search_txt):
    qz=Quiz.query.filter(Quiz.subject_name.ilike(f"%{search_txt}%")).all()
    return qz

def get_quiz_by_date(search_txt):
    qz=Quiz.query.filter(Quiz.date_of_quiz.ilike(f"%{search_txt}%")).all()
    return qz
def get_quiz_by_name_all(search_txt):
    qz=Quiz.query.filter(Quiz.name.ilike(f"%{search_txt}%")).all()
    return qz



@app.route("/user_search/<name>",methods=["GET","POST"])
def user_search(name):
    if request.method=='POST':
        serach_txt=request.form.get("search")
        if serach_txt=="":
            return redirect(url_for("user_dashboard",name=name))
        by_name=get_quiz_by_name_all(serach_txt)
        by_subject=search_by_subject(serach_txt)
        by_date=get_quiz_by_date(serach_txt)
        
        if by_name:
            return render_template("user_search.html",name=name,Quiz=by_name)
        elif by_subject:
            return render_template("user_search.html",name=name,Quiz=by_subject)
        elif by_date:
            return render_template("user_search.html",name=name,Quiz=by_date)
    


    return redirect(url_for('user_dashboard',name=name))

@app.route("/start_quiz/<qname>/<name>")
def start_quiz(qname,name):
    qz=get_quiz_by_name(qname)
    return render_template('start_quiz.html',Quiz=qz,name=name)

def get_user_by_username(uname):
    usr=User.query.filter_by(email=uname).first()
    return usr

@app.route("/submitquiz/<qname>/<uname>", methods=["GET", "POST"])
def submitquiz(qname, uname):
    count = 0
    score = 0
    qz = get_quiz_by_name(qname)
    qnm = qz.name

    if request.method == "POST":
        for question in qz.questions:
            q_id = question.id
            selected_option = request.form.get(str(q_id))  
            correct_option = str(question.correct_option)
            count += 1
            if selected_option == correct_option:
                score += 1

    new_score = Score(quiz_name=qnm, user_name=uname, time_stamp_of_attempt=datetime.now(), total_score=count,marks_obtained=score)
    db.session.add(new_score)
    db.session.commit()

    return redirect(url_for("user_dashboard", name=uname))

def get_score_by_username(name):
    sc=Score.query.filter_by(user_name=name).all()
    return sc


@app.route("/score/<name>")
def score(name):
    sc=get_score_by_username(name)
    return render_template('score.html',Score=sc,name=name)

def get_subj_summary():
    quiz=get_quiz()
    summary={}
    for q in quiz:
        if q.subject_name in summary.keys():
            summary[q.subject_name]+=1
        else:
            summary[q.subject_name]=1
    x_names=list(summary.keys())
    y_numbers=list(summary.values())
    plt.bar(x_names,y_numbers,color="orange",width=0.4)
    plt.title("Subject/Number of Quiz")
    plt.xlabel("Subjects")
    plt.ylabel("Number of Quiz")
    return plt

def get_heighestmarks_summary():
    quiz = get_quiz()  
    summary = {}

    for q in quiz:
        if q.subject_name not in summary:
            summary[q.subject_name] = 0


    for q in quiz:
        if q.subject_name in summary:
            for s in q.scores:
                if int(s.marks_obtained) > int(summary[q.subject_name]):
                    summary[q.subject_name] = int(s.marks_obtained)

    sorted_summary = dict(sorted(summary.items(), key=lambda x:x[1]))

    x_names = list(sorted_summary.keys())
    y_numbers = list(sorted_summary.values())  


    plt.bar(x_names, y_numbers, color="blue", width=0.4)
    plt.title("Subject-wise Highest Marks")
    plt.xlabel("Subjects")
    plt.ylabel("Highest Marks")
    
    return plt


def get_subjectwise_attempt_summary():
    quiz = get_quiz()  
    summary = {}

    for q in quiz:
        if q.subject_name not in summary:
            summary[q.subject_name] = 0


    for q in quiz:
        if q.subject_name in summary:
            for s in q.scores:
                    summary[q.subject_name] +=1


    x_names = list(summary.keys())
    y_numbers = list(summary.values())  


    plt.bar(x_names, y_numbers, color="red", width=0.4)
    plt.title("Subject-wise Attempts")
    plt.xlabel("Subjects")
    plt.ylabel("Number of Attempts")
    
    return plt



@app.route("/admin_summary/<name>")
def admin_summary(name):
    plot=get_heighestmarks_summary()
    plot.savefig("./static/image/admin_heighestmarks_summary.jpeg")
    plot.clf()

    plot=get_subjectwise_attempt_summary()
    plot.savefig("./static/image/admin_subjectwise_attempt_summary.jpeg")
    plot.clf()

    return render_template("admin_summary.html",name=name)


@app.route("/user_summary/<name>")
def user_summary(name):
    plot=get_subj_summary()
    plot.savefig("./static/image/user_subject_summary.jpeg")
    plot.clf()

    return render_template("user_summary.html",name=name)